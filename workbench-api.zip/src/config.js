import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, "..");

// 极简 .env 加载器（不依赖任何 npm 包，Node 22 零依赖可跑）。
// 不覆盖已存在的环境变量。
export function loadEnv(file = path.join(ROOT, ".env")) {
  if (!existsSync(file)) return;
  const raw = readFileSync(file, "utf8");
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][\w.-]*)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
}

loadEnv();

const publicBaseUrl = (process.env.PUBLIC_BASE_URL || "").replace(/\/+$/, "");

function splitScopes(v) {
  return (v || "user_info,video.data,fans.data")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export const config = {
  port: Number(process.env.PORT || 8787),
  publicBaseUrl,
  dataDir: process.env.DATA_DIR || path.join(ROOT, "data"),
  douyin: {
    clientKey: process.env.DOUYIN_CLIENT_KEY || "",
    clientSecret: process.env.DOUYIN_CLIENT_SECRET || "",
    // 抖音 OAuth 回调地址，必须与抖音开放平台后台填写的完全一致。
    redirectUri:
      process.env.DOUYIN_REDIRECT_URI ||
      (publicBaseUrl ? `${publicBaseUrl}/api/douyin/callback` : ""),
    scopes: splitScopes(process.env.DOUYIN_SCOPES),
  },
  wechat: {
    thirdParty: {
      provider: process.env.WECHAT_TP_PROVIDER || "",
      apiKey: process.env.WECHAT_TP_API_KEY || "",
      apiSecret: process.env.WECHAT_TP_API_SECRET || "",
      accountId: process.env.WECHAT_TP_ACCOUNT_ID || "",
    },
  },
  llm: {
    deepseek: process.env.DEEPSEEK_API_KEY || "",
    dashscope: process.env.DASHSCOPE_API_KEY || "",
    // OpenAI（口播成片流水线：Responses API 拆分镜 + Images API 逐镜生图）。
    // 未配置时流水线自动降级：拆分镜走 DeepSeek JSON 模式，生图走通义万相。
    openai: process.env.OPENAI_API_KEY || "",
    openaiBase: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, ""),
    openaiTextModel: process.env.OPENAI_TEXT_MODEL || "gpt-5.2",
    openaiImageModel: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.6-flare",
  },
  kling: {
    // 可灵 AI 开放平台(快手):可图文生图 + Kling 图生视频。JWT 鉴权(AccessKey/SecretKey)。
    accessKey: process.env.KLING_ACCESS_KEY || "",
    secretKey: process.env.KLING_SECRET_KEY || "",
    imageModel: process.env.KLING_IMAGE_MODEL || "kolors",
    videoModel: process.env.KLING_VIDEO_MODEL || "kling-v1",
  },
  feishu: {
    // 飞书知识库（wiki v2）只读接入。用户 OAuth 授权（FEISHU_REDIRECT_URI）后整库可浏览；
    // 未授权时应用身份只能拉显式授权过的单文档（贴链接模式）。
    appId: process.env.FEISHU_APP_ID || "",
    appSecret: process.env.FEISHU_APP_SECRET || "",
    redirectUri: (process.env.FEISHU_REDIRECT_URI || "http://localhost:9090/api/feishu/callback").replace(/\/+$/, ""),
    // 空间白名单(逗号分隔,按空间名精确匹配;空 = 显示全部)。限制工作台只暴露指定知识库。
    spacesFilter: (process.env.FEISHU_SPACES_FILTER || "")
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean),
    // 空间内根路径(如 "文案/口播稿"):目录树从该子目录开始展示;空 = 空间根。
    rootPath: process.env.FEISHU_ROOT_PATH || "",
  },
};
