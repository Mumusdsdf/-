import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { writeFileSync, unlinkSync, mkdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import * as douyin from "./lib/douyin.js";
import * as wechat from "./lib/wechat.js";
import * as llm from "./lib/llm.js";
import { mapVideoData } from "./lib/mapper.js";
import { getToken } from "./lib/store.js";
import { transcribePcm } from "./lib/transcribe.js";
import { generateImage, generateVideo } from "./lib/wanx.js";
import { synthesize, enrollVoice } from "./lib/tts.js";
import { splitScenes, MOTIONS, DEFAULT_STYLE } from "./lib/storyboard.js";
import { image as openaiImage } from "./lib/openai.js";
import { probeDurationSec, renderProject } from "./lib/render.js";
import { generateImage as klingImage, imageToVideo as klingI2V, status as klingStatus } from "./lib/kling.js";
import * as feishu from "./lib/feishu.js";
import { describeReference, describeUiStyle } from "./lib/vl.js";
import {
  listProjects, getProject, saveProject, deleteProject, newProjectId, mediaName,
} from "./lib/videostore.js";

// 零依赖 HTTP 服务。绑定 127.0.0.1，由 nginx 反代对外。
// 路由：方法 + 正则 path。

const routes = [];
function route(method, pattern, handler, opts = {}) {
  routes.push({ method, pattern: new RegExp(`^${pattern}$`), handler, ...opts });
}

function json(res, status, obj) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(JSON.stringify(obj));
}

function redirect(res, url) {
  res.writeHead(302, { Location: url });
  res.end();
}

function html(res, body) {
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(body);
}

async function readJson(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw.trim()) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

// 读原始二进制请求体（文件上传用）。
async function readRaw(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  return Buffer.concat(chunks);
}

// 用 ffmpeg 把任意音视频抽成 16kHz 单声道 PCM，返回 Buffer。
function extractPcm(inputPath) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    const ff = spawn("ffmpeg", [
      "-hide_banner", "-loglevel", "error",
      "-i", inputPath,
      "-vn", "-ac", "1", "-ar", "16000",
      "-f", "s16le", "pipe:1",
    ]);
    ff.stdout.on("data", (c) => chunks.push(c));
    ff.stderr.on("data", (d) => {
      const s = d.toString();
      if (s.trim()) console.error("[ffmpeg]", s.trim().slice(0, 400));
    });
    ff.on("error", (e) => reject(new Error(`ffmpeg 启动失败：${e.message}`)));
    ff.on("close", (code) => {
      if (code !== 0) reject(new Error(`音频提取失败（ffmpeg 退出码 ${code}）`));
      else resolve(Buffer.concat(chunks));
    });
  });
}

// 下载 URL 内容为 Buffer（文生视频的 OSS 地址 24h 有效，需及时拉回本地）。
async function downloadTo(url) {
  const r = await fetch(url);
  if (!r.ok) throw Object.assign(new Error(`下载生成视频失败（HTTP ${r.status}）`), { status: 502 });
  return Buffer.from(await r.arrayBuffer());
}

function parseItemIds(url, body) {
  let ids = [];
  if (Array.isArray(body?.item_ids)) ids = body.item_ids;
  else if (typeof url.searchParams.get("item_ids") === "string") {
    ids = url.searchParams.get("item_ids").split(",").filter(Boolean);
  }
  return ids;
}

// ---- 基础 ----
route("GET", "/api/health", async ({ res }) => {
  const dt = getToken("douyin");
  json(res, 200, {
    ok: true,
    version: "0.1.0",
    douyin: {
      configured: Boolean(config.douyin.clientKey && config.douyin.clientSecret),
      redirectUri: config.douyin.redirectUri,
      authorized: Boolean(dt?.accessToken),
      openId: dt?.openId ?? null,
    },
    wechat: wechat.status(),
    // 生图模型可用性(前端成片工厂选模型时实时提示用)。
    imageGen: {
      openai: Boolean(config.llm.openai),
      kling: klingStatus().configured,
      wanx: true,
    },
  });
});

// ---- 抖音 OAuth ----
route("GET", "/api/douyin/authorize", async ({ res, url }) => {
  redirect(res, douyin.authorizeUrl(url.searchParams.get("state") ?? ""));
});

route("GET", "/api/douyin/callback", async ({ res, url }) => {
  const code = url.searchParams.get("code");
  const err = url.searchParams.get("error");
  if (err || !code) {
    html(res, `<h1>授权失败</h1><p>${err || "缺少 code"}</p>`);
    return;
  }
  try {
    const t = await douyin.exchangeCode(code);
    html(res, `<h1>抖音授权成功</h1><p>open_id: ${t.openId}</p><p>已保存 token，可关闭本页。</p>`);
  } catch (e) {
    html(res, `<h1>抖音授权失败</h1><p>${e.message}</p>`);
  }
});

// ---- 抖音数据 ----
route("GET", "/api/douyin/status", async ({ res }) => {
  const user = await douyin.getUserInfo();
  json(res, 200, { ok: true, user });
});

route("GET", "/api/douyin/videos", async ({ res, url }) => {
  const data = await douyin.listVideos(
    Number(url.searchParams.get("cursor") || 0),
    Number(url.searchParams.get("count") || 20),
  );
  json(res, 200, { ok: true, ...data });
});

route("POST", "/api/douyin/video-data", async ({ res, url, body }) => {
  const ids = parseItemIds(url, body);
  if (!ids.length) return json(res, 400, { ok: false, error: "item_ids 必填" });
  const data = await douyin.getVideoData(ids);
  json(res, 200, { ok: true, list: (data.list ?? []).map(mapVideoData) });
});

// ---- 统一指标出口（工作台快照用）----
// GET /api/metrics?item_ids=xxx,yyy  或  POST /api/metrics { item_ids: [...] }
route("GET", "/api/metrics", async ({ res, url }) => {
  const ids = parseItemIds(url, {});
  if (!ids.length) return json(res, 400, { ok: false, error: "item_ids 必填" });
  const data = await douyin.getVideoData(ids);
  json(res, 200, { ok: true, list: (data.list ?? []).map(mapVideoData) });
});

route("POST", "/api/metrics", async ({ res, url, body }) => {
  const ids = parseItemIds(url, body);
  if (!ids.length) return json(res, 400, { ok: false, error: "item_ids 必填" });
  const data = await douyin.getVideoData(ids);
  json(res, 200, { ok: true, list: (data.list ?? []).map(mapVideoData) });
});

// 大模型重写口播各段正文（脚本工厂「AI 写稿」）。
route("POST", "/api/llm/script", async ({ res, body }) => {
  const { topic, hook, sections, provider } = body ?? {};
  if (!topic?.title || !Array.isArray(sections) || !sections.length) {
    return json(res, 400, { ok: false, error: "缺少 topic.title 或 sections" });
  }
  const out = await llm.rewriteSections({ topic, hook: hook ?? "反常识", sections, materials: body?.materials, provider });
  json(res, 200, { ok: true, sections: out });
});

// 单段合规修复：只重写这一段，消除列出的阻断项（脚本工厂「只重写这一段」）。
route("POST", "/api/llm/section-fix", async ({ res, body }) => {
  const { topic, sectionKey, label, text, issues, provider } = body ?? {};
  if (!text || !sectionKey) return json(res, 400, { ok: false, error: "缺少 sectionKey 或 text" });
  const out = await llm.fixSection({
    topic,
    sectionKey,
    label,
    text,
    issues: Array.isArray(issues) ? issues : [],
    provider,
  });
  json(res, 200, { ok: true, text: out });
});

// 资产起草兜底:段落需要挂资产但库里为空,AI 起草一条草稿(不虚构具体客户/数据,待人工核实)。
route("POST", "/api/llm/asset-draft", async ({ res, body }) => {
  const { topic, sectionLabel, text, provider } = body ?? {};
  if (!text) return json(res, 400, { ok: false, error: "缺少 text" });
  const out = await llm.draftAsset({ topic, sectionLabel, text, provider });
  json(res, 200, { ok: true, ...out });
});

// 选题立项：把热点扩充成选题字段。
route("POST", "/api/llm/topic", async ({ res, body }) => {
  const { title, angle, audience, provider } = body ?? {};
  if (!title) return json(res, 400, { ok: false, error: "缺少 title" });
  const out = await llm.enrichTopic({ title, angle, audience, provider });
  json(res, 200, { ok: true, ...out });
});

// 复盘诊断：自然语言结论 + 下一步。
route("POST", "/api/llm/diagnose", async ({ res, body }) => {
  const out = await llm.diagnoseSummary(body ?? {});
  json(res, 200, { ok: true, ...out });
});

// 资产提取：从纪要/口述挑可复用资产。
route("POST", "/api/llm/assets", async ({ res, body }) => {
  const { text, provider } = body ?? {};
  if (!text) return json(res, 400, { ok: false, error: "缺少 text" });
  const out = await llm.extractAssets({ text, provider });
  json(res, 200, { ok: true, items: out.items });
});

// 视频/音频转写：上传原始文件（raw body），抽音轨 → 百炼实时 ASR → 返回全文。
route("POST", "/api/transcribe", async ({ res, body }) => {
  if (!body?.length) return json(res, 400, { ok: false, error: "请求体为空" });
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const inPath = path.join(config.dataDir, `upload-${id}.bin`);
  try {
    writeFileSync(inPath, body);
    const pcm = await extractPcm(inPath);
    if (!pcm.length) return json(res, 400, { ok: false, error: "未能从文件中提取音频（可能不含音轨）" });
    const text = await transcribePcm(pcm);
    json(res, 200, { ok: true, text });
  } finally {
    try { unlinkSync(inPath); } catch { /* ignore */ }
  }
}, { raw: true });

// 文生视频：提交描述词 → 异步生成 → 拉回本地并返回可访问地址。
route("POST", "/api/wen-video", async ({ res, body }) => {
  const { prompt, size } = body ?? {};
  if (!prompt?.trim()) return json(res, 400, { ok: false, error: "缺少描述词 prompt" });
  const chosenSize = size || "1080*1920";
  const { videoUrl } = await generateVideo(prompt, { size: chosenSize });
  const mediaDir = path.join(config.dataDir, "media");
  mkdirSync(mediaDir, { recursive: true });
  const id = `wv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const filePath = path.join(mediaDir, `${id}.mp4`);
  const buf = await downloadTo(videoUrl);
  writeFileSync(filePath, buf);
  json(res, 200, {
    ok: true,
    video: {
      id,
      prompt: prompt.trim(),
      size: chosenSize,
      url: `/api/media/${id}.mp4`,
      createdAt: new Date().toISOString(),
    },
  });
});

// 文生图：提交描述词 → 异步生成 → 拉回本地并返回可访问地址。
route("POST", "/api/wen-image", async ({ res, body }) => {
  const { prompt, size, n } = body ?? {};
  if (!prompt?.trim()) return json(res, 400, { ok: false, error: "缺少描述词 prompt" });
  const chosenSize = size || "1024*1024";
  const { imageUrls } = await generateImage(prompt, { size: chosenSize, n: Number(n) || 1 });
  const mediaDir = path.join(config.dataDir, "media");
  mkdirSync(mediaDir, { recursive: true });
  const images = [];
  for (const u of imageUrls) {
    const ext = (u.split("?")[0].match(/\.(png|jpe?g|webp)$/i) || [null, "png"])[1].toLowerCase();
    const id = `wi-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const filePath = path.join(mediaDir, `${id}.${ext}`);
    const buf = await downloadTo(u);
    writeFileSync(filePath, buf);
    images.push({ id, url: `/api/media/${id}.${ext}` });
  }
  json(res, 200, {
    ok: true,
    prompt: prompt.trim(),
    size: chosenSize,
    images,
    createdAt: new Date().toISOString(),
  });
});

// 本地媒体文件（生成的视频/图片/音频），供 <video>/<img>/<audio> 直接播放。
route("GET", "/api/media/([\\w-]+\\.(?:mp4|mp3|png|jpe?g|webp))", async ({ res, params }) => {
  const name = params[1];
  const ext = name.split(".").pop().toLowerCase();
  const types = { mp4: "video/mp4", mp3: "audio/mpeg", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp" };
  const filePath = path.join(config.dataDir, "media", name);
  try {
    const buf = readFileSync(filePath);
    res.writeHead(200, {
      "Content-Type": types[ext] || "application/octet-stream",
      "Content-Length": buf.length,
      "Cache-Control": "public, max-age=31536000, immutable",
    });
    res.end(buf);
  } catch {
    json(res, 404, { ok: false, error: "not_found" });
  }
});

// 口播成片：文字转语音（CosyVoice v2），下载到本地返回可访问地址。
route("POST", "/api/tts", async ({ res, body }) => {
  const { text, voice } = body ?? {};
  if (!text?.trim()) return json(res, 400, { ok: false, error: "缺少要合成的文本 text" });
  const { url: audioUrl } = await synthesize(text, { voice });
  const mediaDir = path.join(config.dataDir, "media");
  mkdirSync(mediaDir, { recursive: true });
  const id = `tts-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const filePath = path.join(mediaDir, `${id}.mp3`);
  const buf = await downloadTo(audioUrl);
  writeFileSync(filePath, buf);
  json(res, 200, {
    ok: true,
    audio: {
      id,
      text: text.trim(),
      voice: voice || "longxiaochun_v2",
      url: `/api/media/${id}.mp3`,
      createdAt: new Date().toISOString(),
    },
  });
});

// 声音复刻：上传参考音频（raw body），创建克隆音色，返回 voice_id（可直接用于 /api/tts 的 voice 参数）。
route("POST", "/api/voice-clone", async ({ res, body, url }) => {
  if (!body?.length) return json(res, 400, { ok: false, error: "请求体为空（需上传参考音频）" });
  const name = (url.searchParams.get("name") || "我的声音").slice(0, 20);
  const prefix = (url.searchParams.get("prefix") || "qjj").slice(0, 12);
  const { voiceId } = await enrollVoice(body, { prefix });
  json(res, 200, { ok: true, voice: { id: voiceId, name, createdAt: new Date().toISOString() } });
}, { raw: true });

// ---- 口播成片流水线（分镜 → 逐镜生图 → 逐镜配音 → 渲染 MP4）----

const MEDIA_DIR = path.join(config.dataDir, "media");

function mediaFileOf(entry) {
  if (!entry?.url) return null;
  const name = entry.url.split("/").pop();
  return path.join(MEDIA_DIR, name);
}

function saveMedia(name, buf) {
  mkdirSync(MEDIA_DIR, { recursive: true });
  const filePath = path.join(MEDIA_DIR, name);
  writeFileSync(filePath, buf);
  return { id: name.replace(/\.\w+$/, ""), url: `/api/media/${name}`, file: filePath };
}

function refreshStatus(project, stage) {
  const scenes = project.scenes ?? [];
  if (stage === "storyboard") return "storyboard";
  if (stage === "image") return scenes.every((s) => s.imageId) ? "shot" : "storyboard";
  if (stage === "narration") return scenes.every((s) => s.audioId && s.durationSec) ? "narrated" : project.status;
  if (stage === "render") return "rendered";
  return project.status;
}

// 重算时间轴：startSec 累计、总时长。
function rebuildTimeline(project) {
  let t = 0;
  for (const s of project.scenes ?? []) {
    s.startSec = t;
    t += Number(s.durationSec) || 0;
  }
  project.totalDurationSec = Math.round(t * 10) / 10;
}

route("GET", "/api/video/projects", async ({ res }) => {
  json(res, 200, { ok: true, projects: listProjects() });
});

route("POST", "/api/video/project", async ({ res, body }) => {
  const { script, title, scriptId, topicId, voice, style } = body ?? {};
  if (!script?.trim()) return json(res, 400, { ok: false, error: "缺少口播稿 script" });
  const project = {
    id: newProjectId(),
    title: String(title || script.trim().slice(0, 16)).slice(0, 40),
    scriptId: scriptId ? String(scriptId) : undefined,
    topicId: topicId ? String(topicId) : undefined,
    script: script.trim(),
    voice: String(voice || "longxiaochun_v2"),
    // 画面风格(拆分镜时注入每个 image_prompt;换风格后重新拆分镜生效)。
    style: String(style || "").trim().slice(0, 200),
    status: "draft",
    scenes: [],
    totalDurationSec: 0,
    createdAt: new Date().toISOString(),
  };
  saveProject(project);
  json(res, 200, { ok: true, project });
});

route("GET", "/api/video/project/([\\w-]+)", async ({ res, params }) => {
  const project = getProject(params[1]);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  json(res, 200, { ok: true, project, renderJob: renderJobs.get(project.id) ?? null });
});

route("DELETE", "/api/video/project/([\\w-]+)", async ({ res, params }) => {
  const ok = deleteProject(params[1]);
  if (!ok) return json(res, 404, { ok: false, error: "项目不存在" });
  json(res, 200, { ok: true });
});

// 全稿拆分镜（整表覆盖，前端先确认）。body.style 可选——传了就更新 project.style（换风格重拆）。
route("POST", "/api/video/storyboard", async ({ res, body }) => {
  const { projectId, sceneCount, style } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  if (style !== undefined && String(style).trim()) project.style = String(style).trim().slice(0, 200);
  const { scenes, provider } = await splitScenes({
    script: project.script,
    sceneCount: Number(sceneCount) || undefined,
    style: project.style,
  });
  project.scenes = scenes;
  project.status = "storyboard";
  project.totalDurationSec = 0;
  saveProject(project);
  json(res, 200, { ok: true, project, provider });
});

// 只改画面风格（不重拆；已生成的镜不受影响，重新拆分镜后新 prompt 带新风格）。
route("PUT", "/api/video/style", async ({ res, body }) => {
  const { projectId, style } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  project.style = String(style ?? "").trim().slice(0, 200);
  saveProject(project);
  json(res, 200, { ok: true, project });
});

// 改单镜（提示词 / 动效）。
route("PUT", "/api/video/scene", async ({ res, body }) => {
  const { projectId, sceneId, image_prompt, motion } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const scene = (project.scenes ?? []).find((s) => s.scene_id === sceneId);
  if (!scene) return json(res, 404, { ok: false, error: `镜头 ${sceneId} 不存在` });
  if (image_prompt !== undefined) scene.image_prompt = String(image_prompt).trim().slice(0, 2000);
  if (motion !== undefined) {
    if (!MOTIONS.includes(motion)) return json(res, 400, { ok: false, error: `动效必须是 ${MOTIONS.join("/")}` });
    scene.motion = motion;
  }
  project.status = refreshStatus(project, "image");
  saveProject(project);
  json(res, 200, { ok: true, project });
});

// 逐镜生图：provider 可选 auto（默认，OpenAI 有 key 用 OpenAI）/ openai / wanx。
// OpenAI Images API（gpt-image，可带参考图 /edits 防外观漂移）；万相走通义 wan2.2 竖屏。
route("POST", "/api/video/scene/image", async ({ res, body }) => {
  const { projectId, sceneId, referenceId, provider: wanted } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const scene = (project.scenes ?? []).find((s) => s.scene_id === sceneId);
  if (!scene) return json(res, 404, { ok: false, error: `镜头 ${sceneId} 不存在` });
  if (!scene.image_prompt?.trim()) return json(res, 400, { ok: false, error: "该镜头没有画面提示词" });

  const provider = ["openai", "wanx", "kling"].includes(wanted) ? wanted : "auto";
  const useOpenai = provider === "wanx" || provider === "kling"
    ? false
    : Boolean(config.llm.openai) || provider === "openai";
  if (provider === "openai" && !config.llm.openai) {
    return json(res, 400, { ok: false, error: "OpenAI 未配置（.env 缺 OPENAI_API_KEY），请切回万相或自动" });
  }
  if (provider === "kling" && !klingStatus().configured) {
    return json(res, 400, { ok: false, error: "可灵未配置（.env 缺 KLING_ACCESS_KEY / KLING_SECRET_KEY）" });
  }

  // 风格与分镜解耦:生图时统一拼「项目风格 + 外观锚(参考图提取) + 镜头内容」。
  // 兼容旧分镜(prompt 里已带旧风格前缀):开头与风格撞车则不重复拼。
  const styleText = (project.style || DEFAULT_STYLE).trim();
  const anchor = String(project.reference?.anchor ?? "").trim();
  const rawPrompt = scene.image_prompt.trim();
  const sameHead = styleText.slice(0, 6) && rawPrompt.slice(0, 6) === styleText.slice(0, 6);
  const styledPrompt = [sameHead ? null : styleText, anchor || null, rawPrompt].filter(Boolean).join("，");

  let providerUsed = provider === "kling" ? "kling" : (useOpenai ? "openai" : "wanx");
  let media;

  // 单次生图(prompt → media),供原 prompt 与脱敏重写后各调一次。
  const genOnce = async (prompt) => {
    if (useOpenai) {
      // 参考图：复用另一个镜头已生成的画面（referenceId = media id），控制人物/产品外观一致。
      let refBuf = null;
      if (referenceId) {
        // 参考图两种来源:另一镜已生成的画面 / 项目上传的参考图(人物/产品原图)。
        let refUrl = null;
        const refScene = (project.scenes ?? []).find((s) => s.imageId === referenceId);
        if (refScene?.image) refUrl = refScene.image;
        else if (project.reference?.id === referenceId) refUrl = project.reference;
        if (!refUrl) throw Object.assign(new Error("参考图不存在（先给被参考的镜头生图,或上传项目参考图）"), { status: 400 });
        const refFile = mediaFileOf(refUrl);
        try {
          refBuf = readFileSync(refFile);
        } catch {
          throw Object.assign(new Error("参考图文件丢失，请重新生成/重新上传"), { status: 400 });
        }
      }
      const buf = await openaiImage({ prompt, size: "1024x1536", referenceBuf: refBuf });
      return saveMedia(mediaName(project.id, scene.scene_id, "img", "png"), buf);
    }
    const { imageUrls } = await generateImage(prompt, { size: "768*1328", n: 1 });
    const u = imageUrls[0];
    const buf = await downloadTo(u);
    const ext = (u.split("?")[0].match(/\.(png|jpe?g|webp)$/i) || [null, "png"])[1].toLowerCase();
    return saveMedia(mediaName(project.id, scene.scene_id, "img", ext), buf);
  };

  // 可灵(可图)分支:竖屏 768x1344,任务轮询内置。
  const genOnceKling = async (prompt) => {
    const { imageUrls } = await klingImage({ prompt, size: "768x1344", n: 1 });
    const u = imageUrls[0];
    const buf = await downloadTo(u);
    const ext = (u.split("?")[0].match(/\.(png|jpe?g|webp)$/i) || [null, "png"])[1].toLowerCase();
    return saveMedia(mediaName(project.id, scene.scene_id, "img", ext), buf);
  };

  try {
    media = provider === "kling" ? await genOnceKling(styledPrompt) : await genOnce(styledPrompt);
  } catch (e) {
    // 内容安全拦截 → LLM 脱敏改写重试一次;存回脱敏 prompt 避免每次重跑再被拦。
    const blocked = /inappropriate|content|敏感|安全|审核/i.test(e.message ?? "");
    if (!blocked) throw e;
    let sanitized = "";
    try {
      sanitized = await llm.sanitizeImagePrompt({ prompt: styledPrompt });
    } catch { /* LLM 挂了走下面的报错 */ }
    if (!sanitized) {
      throw Object.assign(
        new Error(`这镜的提示词被内容安全拦截(常见原因:负面事件/法律纠纷/敏感词)。请在分镜卡片把这镜的「画面提示词」改写成纯画面描述再点重生图。原始报错:${(e.message ?? "").slice(0, 120)}`),
        { status: 400 },
      );
    }
    try {
      media = provider === "kling" ? await genOnceKling(sanitized) : await genOnce(sanitized);
      scene.image_prompt = sanitized; // 脱敏版存回,下次重跑直接过
    } catch (e2) {
      throw Object.assign(
        new Error(`这镜的提示词被内容安全拦截,自动脱敏后仍被拦。请手动改写:去掉负面叙事/纠纷/情绪词,只保留画面(例:「人物在桌前翻看文件,屏幕亮着,房间安静」)。改完点「重生图」。`),
        { status: 400 },
      );
    }
  }


  scene.image = { id: media.id, url: media.url, provider: providerUsed };
  scene.imageId = media.id;
  scene.imageUrl = media.url;
  project.status = refreshStatus(project, "image");
  saveProject(project);
  json(res, 200, { ok: true, project, provider: providerUsed, image: scene.image });
});

// ---- 图生视频(可灵):把某镜已生成的静态图变成 5s 运动镜头。后台任务制(生成 1-5 分钟) ----
const ivideoJobs = new Map(); // `${projectId}|${sceneId}` → { status, error, url, startedAt }

route("POST", "/api/video/scene/ivideo", async ({ res, body }) => {
  const { projectId, sceneId, prompt } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const scene = (project.scenes ?? []).find((s) => s.scene_id === sceneId);
  if (!scene) return json(res, 404, { ok: false, error: `镜头 ${sceneId} 不存在` });
  if (!scene.imageId) return json(res, 400, { ok: false, error: "该镜头还没生图,先生成静态图" });
  if (!klingStatus().configured) return json(res, 503, { ok: false, error: "可灵未配置(.env 缺 KLING_ACCESS_KEY/SECRET_KEY)" });
  const key = `${projectId}|${sceneId}`;
  if (ivideoJobs.get(key)?.status === "running") return json(res, 200, { ok: true, job: ivideoJobs.get(key) });

  const job = { status: "running", error: null, url: scene.video?.url ?? null, startedAt: new Date().toISOString() };
  ivideoJobs.set(key, job);
  json(res, 200, { ok: true, job });

  // 后台:读镜图 → base64 → 可灵图生视频 → 下载存 media → scene.video 持久化。
  const imgFile = mediaFileOf(scene.image);
  const videoPrompt = [project.style, String(prompt ?? scene.image_prompt)].filter(Boolean).join("，");
  try {
    const imgBuf = readFileSync(imgFile);
    const { videoUrl } = await klingI2V({ imageBase64: imgBuf.toString("base64"), prompt: videoPrompt, duration: 5 });
    const buf = await downloadTo(videoUrl);
    const media = saveMedia(mediaName(project.id, scene.scene_id, "ivideo", "mp4"), buf);
    scene.video = { id: media.id, url: media.url, provider: "kling", createdAt: new Date().toISOString() };
    saveProject(project);
    job.status = "done";
    job.url = media.url;
  } catch (e) {
    job.status = "error";
    job.error = e.message;
  }
});

route("GET", "/api/video/scene/ivideo", async ({ res, url }) => {
  const projectId = url.searchParams.get("projectId") || "";
  const sceneId = url.searchParams.get("sceneId") || "";
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const job = ivideoJobs.get(`${projectId}|${sceneId}`);
  const scene = (project.scenes ?? []).find((s) => s.scene_id === sceneId);
  json(res, 200, { ok: true, job: job ?? null, video: scene?.video ?? null });
});

// 逐镜配音（CosyVoice v2，可用全姐姐克隆音色）+ ffprobe 实测时长 → 时间轴。
// sceneId 传则只重配该镜；不传则整片重配。
// ---- 项目参考图(用户上传图片/视频 → qwen-vl 提取外观锚 → 生图全程一致) ----

// 视频抽帧:取 0.5s 处一帧存 PNG。
function extractFrame(inputPath, outPath) {
  return new Promise((resolve, reject) => {
    const ff = spawn("ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-ss", "0.5", "-i", inputPath, "-frames:v", "1", outPath]);
    let err = "";
    ff.stderr.on("data", (d) => (err += d.toString()));
    ff.on("error", (e) => reject(Object.assign(new Error(`ffmpeg 启动失败：${e.message}`), { status: 500 })));
    ff.on("close", (code) => (code === 0 ? resolve() : reject(Object.assign(new Error(`抽帧失败：${err.slice(-200)}`), { status: 500 }))));
  });
}

// 上传参考图/视频(raw body):图片直接用;视频抽一帧。qwen-vl 提取外观锚存进 project.reference。
route("POST", "/api/video/reference", async ({ res, req, body, url }) => {
  const projectId = url.searchParams.get("projectId") || "";
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  if (!body?.length) return json(res, 400, { ok: false, error: "请求体为空(需上传图片或视频)" });

  const ctype = String(req.headers["content-type"] || "");
  let imgBuf = Buffer.from(body);
  let mime = "image/png";
  const tmpDir = path.join(config.dataDir, "render", project.id);
  mkdirSync(tmpDir, { recursive: true });
  if (ctype.startsWith("video/")) {
    // 视频:落临时文件抽 0.5s 一帧。
    const tmpIn = path.join(tmpDir, "ref-upload.tmp");
    const tmpOut = path.join(tmpDir, "ref-frame.png");
    writeFileSync(tmpIn, imgBuf);
    try {
      await extractFrame(tmpIn, tmpOut);
      imgBuf = readFileSync(tmpOut);
    } finally {
      try { unlinkSync(tmpIn); } catch { /* ignore */ }
      try { unlinkSync(tmpOut); } catch { /* ignore */ }
    }
  } else if (ctype.startsWith("image/")) {
    mime = ctype;
  } else if (imgBuf[0] === 0xff && imgBuf[1] === 0xd8) {
    mime = "image/jpeg";
  }

  // qwen-vl 提取外观锚(失败不阻断:图存了,锚可后补/手写)。
  let anchor = "";
  try {
    anchor = await describeReference(imgBuf, mime);
  } catch (e) {
    anchor = "";
  }
  const ext = mime.includes("jpeg") ? "jpg" : "png";
  const media = saveMedia(mediaName(project.id, "ref", "ref", ext), imgBuf);
  project.reference = { id: media.id, url: media.url, anchor, createdAt: new Date().toISOString() };
  saveProject(project);
  json(res, 200, { ok: true, project, reference: project.reference, anchorGenerated: Boolean(anchor) });
}, { raw: true });

// 手动改外观锚(图不变,只改描述)。
route("PUT", "/api/video/reference/anchor", async ({ res, body }) => {
  const { projectId, anchor } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  if (!project.reference) return json(res, 400, { ok: false, error: "还没有上传参考图" });
  project.reference.anchor = String(anchor ?? "").trim().slice(0, 300);
  saveProject(project);
  json(res, 200, { ok: true, project });
});

// 删除参考图。
route("DELETE", "/api/video/reference", async ({ res, url }) => {
  const projectId = url.searchParams.get("projectId") || "";
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  delete project.reference;
  saveProject(project);
  json(res, 200, { ok: true, project });
});

route("POST", "/api/video/narration", async ({ res, body }) => {
  const { projectId, sceneId } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const targets = (project.scenes ?? []).filter((s) => !sceneId || s.scene_id === sceneId);
  if (!targets.length) return json(res, 400, { ok: false, error: "没有可配音的镜头" });

  for (const scene of targets) {
    const { url: ossUrl } = await synthesize(scene.text, { voice: project.voice });
    const buf = await downloadTo(ossUrl);
    const media = saveMedia(mediaName(project.id, scene.scene_id, "aud", "mp3"), buf);
    scene.audio = { id: media.id, url: media.url };
    scene.audioId = media.id;
    scene.audioUrl = media.url;
    scene.durationSec = Math.round((await probeDurationSec(media.file)) * 100) / 100;
  }
  rebuildTimeline(project);
  project.status = refreshStatus(project, "narration");
  saveProject(project);
  json(res, 200, { ok: true, project });
});

// 渲染合成：后台任务制（进度轮询），完成后产物落 media。
const renderJobs = new Map(); // projectId → { status, done, total, error, outputUrl, startedAt, finishedAt }

route("POST", "/api/video/render", async ({ res, body }) => {
  const { projectId, subtitles } = body ?? {};
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  const existing = renderJobs.get(projectId);
  if (existing?.status === "running") return json(res, 200, { ok: true, job: existing });

  // 字幕开关随项目持久化（undefined = 默认烧录；false = 纯画面成片）。开关变化会触发全片重渲（指纹含字幕）。
  if (subtitles !== undefined) {
    const next = Boolean(subtitles);
    if (project.subtitles !== next) {
      project.subtitles = next;
      saveProject(project);
    }
  }

  const scenes = project.scenes ?? [];
  const missing = scenes.filter((s) => !s.imageId || !s.audioId || !s.durationSec);
  if (!scenes.length) return json(res, 400, { ok: false, error: "还没有分镜" });
  if (missing.length) {
    return json(res, 400, { ok: false, error: `镜头 ${missing.map((s) => s.scene_id).join("、")} 还没生图/配音` });
  }

  const job = { status: "running", done: 0, total: scenes.length, error: null, outputUrl: null, startedAt: new Date().toISOString() };
  renderJobs.set(projectId, job);
  json(res, 200, { ok: true, job });

  // 后台渲染（不占请求；失败记进 job，项目状态回退）。
  const renderInput = {
    ...project,
    scenes: scenes.map((s) => ({
      ...s,
      imageFile: mediaFileOf(s.image),
      audioFile: mediaFileOf(s.audio),
    })),
  };
  try {
    const outFile = await renderProject({
      project: renderInput,
      onProgress: (done, total, sid) => {
        job.done = done;
        job.total = total;
      },
    });
    const media = saveMedia(mediaName(project.id, "out", "render", "mp4"), readFileSync(outFile));
    project.output = { id: media.id, url: media.url };
    project.outputUrl = media.url;
    project.renderedAt = new Date().toISOString();
    project.status = "rendered";
    saveProject(project);
    job.status = "done";
    job.outputUrl = media.url;
    job.finishedAt = new Date().toISOString();
  } catch (e) {
    job.status = "error";
    job.error = e.message;
    job.finishedAt = new Date().toISOString();
  }
});

route("GET", "/api/video/progress", async ({ res, url }) => {
  const projectId = url.searchParams.get("projectId") || "";
  const project = getProject(projectId);
  if (!project) return json(res, 404, { ok: false, error: "项目不存在" });
  json(res, 200, { ok: true, job: renderJobs.get(projectId) ?? null, project });
});

// ---- 飞书知识库（只读：空间列表 / 节点树 / docx 正文）----
route("GET", "/api/feishu/status", async ({ res }) => {
  json(res, 200, { ok: true, ...feishu.status() });
});

// 用户 OAuth 授权入口：整页跳转，授权后回 callback。
route("GET", "/api/feishu/authorize", async ({ res }) => {
  res.writeHead(302, { Location: feishu.authorizeUrl() });
  return res.end();
});

// OAuth 回调：code 换 user_access_token 持久化，然后回前端首页。
route("GET", "/api/feishu/callback", async ({ res, url }) => {
  const code = url.searchParams.get("code");
  if (!code) return json(res, 400, { ok: false, error: "缺少 code（飞书授权回调参数不全）" });
  await feishu.exchangeCode(code);
  res.writeHead(302, { Location: "/?feishu=authorized" });
  return res.end();
});

route("GET", "/api/feishu/spaces", async ({ res }) => {
  json(res, 200, { ok: true, spaces: await feishu.listSpaces() });
});

route("GET", "/api/feishu/nodes", async ({ res, url }) => {
  const spaceId = url.searchParams.get("spaceId") || "";
  const parent = url.searchParams.get("parent") || "";
  if (!spaceId) return json(res, 400, { ok: false, error: "缺少 spaceId" });
  json(res, 200, { ok: true, nodes: await feishu.listNodes(spaceId, parent) });
});

route("GET", "/api/feishu/doc", async ({ res, url }) => {
  const token = url.searchParams.get("token") || "";
  if (!token) return json(res, 400, { ok: false, error: "缺少 token（知识库节点 node_token）" });
  json(res, 200, { ok: true, doc: await feishu.getDoc(token) });
});

// ---- 前端风格参考(上传设计图 → qwen-vl 提取 UI 风格 → 存档供前端换肤) ----
route("POST", "/api/ui-style", async ({ res, req, body }) => {
  if (!body?.length) return json(res, 400, { ok: false, error: "请求体为空(需上传图片)" });
  const ctype = String(req.headers["content-type"] || "");
  const mime = ctype.startsWith("image/") ? ctype : "image/png";
  try {
    const style = await describeUiStyle(Buffer.from(body), mime);
    writeFileSync(path.join(config.dataDir, "ui-style.json"), JSON.stringify({
      style, imageType: mime, updatedAt: new Date().toISOString(),
    }), "utf8");
    json(res, 200, { ok: true, style });
  } catch (e) {
    json(res, 502, { ok: false, error: e.message });
  }
}, { raw: true });

route("GET", "/api/ui-style", async ({ res }) => {
  try {
    const j = JSON.parse(readFileSync(path.join(config.dataDir, "ui-style.json"), "utf8"));
    json(res, 200, { ok: true, ...j });
  } catch {
    json(res, 200, { ok: true, exists: false });
  }
});

// ---- 数据持久化（前端 localStorage 的云端备份/同步）----
const DB_FILE = path.join(config.dataDir, "db.json");
function readDbFile() {
  try { return JSON.parse(readFileSync(DB_FILE, "utf8")); } catch { return null; }
}

route("GET", "/api/db", async ({ res }) => {
  const store = readDbFile();
  if (!store?.data) return json(res, 200, { ok: true, exists: false });
  json(res, 200, { ok: true, exists: true, updatedAt: store.updatedAt || 0, data: store.data });
});

route("PUT", "/api/db", async ({ res, body }) => {
  const { data, updatedAt } = body ?? {};
  if (!data || typeof data !== "object") return json(res, 400, { ok: false, error: "缺少 data" });
  mkdirSync(config.dataDir, { recursive: true });
  writeFileSync(DB_FILE, JSON.stringify({ data, updatedAt: updatedAt || Date.now() }));
  json(res, 200, { ok: true });
});

// ---- 服务 ----
const server = createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const m = r.pattern.exec(url.pathname);
    if (!m) continue;
    const body = ["POST", "PUT", "PATCH"].includes(req.method)
      ? await (r.raw ? readRaw(req) : readJson(req))
      : {};
    try {
      await r.handler({ req, res, url, params: m, body });
    } catch (e) {
      console.error(`[${req.method} ${url.pathname}] ${e.message}`);
      json(res, e.status || 500, { ok: false, error: e.message });
    }
    return;
  }
  json(res, 404, { ok: false, error: "not_found" });
});

server.listen(config.port, "127.0.0.1", () => {
  console.log(`workbench-api  listening on http://127.0.0.1:${config.port}`);
  console.log(`  抖音已配置: ${Boolean(config.douyin.clientKey && config.douyin.clientSecret)}`);
  console.log(`  抖音回调:   ${config.douyin.redirectUri || "(未配置，需 PUBLIC_BASE_URL)"}`);
  console.log(`  视频号:     ${wechat.status().provider || "未配置第三方数据平台"}`);
});
