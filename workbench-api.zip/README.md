# workbench-api · 平台数据接入后端

全姐姐 AI 内容工作台的平台数据桥接层。零依赖（Node 22 原生 `http` + `fetch`），
负责把抖音/微信视频号的数据拉回来，映射成工作台 `Metrics` 的 9 个字段，
供「发布与回收」「复盘诊断」自动回填快照。

## 现状与边界

| 平台 | 数据回收 | 说明 |
|---|---|---|
| 抖音 | ✅ 官方 API | 走抖音开放平台「数据开放服务」，OAuth 授权后拉视频数据/粉丝数据 |
| 微信视频号 | ⚠️ 第三方 | 官方**不开放**短视频数据 API，需第三方数据平台（新视/友望/视向标/飞瓜）授权 |

抖音视频数据接口能返回：播放/点赞/评论/转发/收藏。
**完播率、平均播放时长、涨粉、主页访问**官方该接口不返回，需要企业号后台或更高级数据权限；
后端统一标「未获取」（`missing` 字段），符合工作台「不估算、缺失标未获取」的原则。

## 目录

```
src/
  server.js        HTTP 服务 + 路由
  config.js        .env 加载 + 配置
  lib/douyin.js    抖音 OAuth + 数据接口
  lib/wechat.js    视频号第三方数据占位
  lib/mapper.js    抖音数据 → 工作台 Metrics 映射
  lib/store.js     token 落盘（data/tokens.json, 0600）
deploy/
  nginx-api.conf           /api/ 反代片段
  workbench-api.service    systemd 单元
```

## 快速开始

```bash
cd workbench-api
cp .env.example .env      # 填密钥
npm run check             # 语法检查
npm start                 # 监听 127.0.0.1:8787
curl http://127.0.0.1:8787/api/health
```

## 环境变量（.env）

- `PUBLIC_BASE_URL`：对外域名（如 `https://youyuexinxi.com.cn`），用于拼抖音回调。
- `DOUYIN_CLIENT_KEY` / `DOUYIN_CLIENT_SECRET`：抖音开放平台应用里拿到的 Client Key / Secret。
- `DOUYIN_REDIRECT_URI`：留空自动用 `PUBLIC_BASE_URL/api/douyin/callback`。
- `DOUYIN_SCOPES`：授权 scope，数据回收默认 `user_info,video.data,fans.data`。
- `WECHAT_TP_*`：视频号第三方数据平台（暂未实现，见 `lib/wechat.js`）。

## 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/health` | 配置与授权状态 |
| GET | `/api/douyin/authorize` | 跳转抖音授权（扫码） |
| GET | `/api/douyin/callback` | 抖音 OAuth 回调（填进抖音后台的回调地址） |
| GET | `/api/douyin/status` | 授权后的用户信息 |
| GET | `/api/douyin/videos?cursor=&count=` | 视频列表 |
| POST | `/api/douyin/video-data` | `{ item_ids: [] }` → 视频数据 |
| GET/POST | `/api/metrics?item_ids=a,b` | 统一指标出口，返回工作台 `Metrics` 结构 |

`/api/metrics` 返回示例：

```json
{
  "ok": true,
  "list": [
    {
      "itemId": "7365...",
      "title": "…",
      "metrics": { "play": 14200, "completion": null, "avgDuration": null,
                   "like": 610, "comment": 74, "share": 92, "save": 140,
                   "follow": null, "profile": null },
      "missing": ["completion", "avgDuration", "follow", "profile"]
    }
  ]
}
```

## 授权流程（抖音）

1. 填好 `DOUYIN_CLIENT_KEY/SECRET` 与 `PUBLIC_BASE_URL`，重启服务。
2. 浏览器打开 `http://<域名>/api/douyin/authorize`，用目标抖音号扫码。
3. 抖音回调到 `PUBLIC_BASE_URL/api/douyin/callback?code=…`，后端换 token 并落盘。
4. token 有效期约 15 天，后端会自动用 refresh_token 滚动续期；失效需重新授权。

## 部署

```bash
# 1) 反代 /api/（片段见 deploy/nginx-api.conf）
sudo nginx -t && sudo systemctl reload nginx
# 2) 系统服务
sudo cp deploy/workbench-api.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now workbench-api
```

## 待办

- [ ] 微信视频号第三方数据平台适配（拿到新视/友望账号后实现 `lib/wechat.js` 的 getVideoData）
- [ ] 完播率/平均时长/涨粉/主页访问：接入企业号后台或扩展数据权限后补齐
- [ ] 前端接入：`Publish.tsx` 的「数据快照」改成调 `/api/metrics` 自动回填
