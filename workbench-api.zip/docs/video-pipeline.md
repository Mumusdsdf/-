# 口播成片流水线 · 补全计划 v1

> 目标：一条 30 秒竖屏（1080×1920）口播视频验证全链路 —— 6-8 个镜头，每镜一张图 + 一个动效，
> 字幕由渲染阶段叠加，导出 MP4。`scene_id` 贯穿原稿 / 图片 / 音频 / 片段，改一镜可单独重跑。

## 一、现状盘点（已有的直接复用）

| 环节 | 现状 | 落点 |
|---|---|---|
| 口播稿 | ✅ `/api/llm/script`（DeepSeek/Qwen，分 section 重写） | 脚本工厂产物直接作为输入 |
| 旁白配音 | ✅ `/api/tts`（百炼 CosyVoice v2）+ `/api/voice-clone`（全姐姐克隆音色） | **不引入 OpenAI Realtime 配音**，复用已有音色资产 |
| 语音识别 | ✅ `/api/transcribe`（Paraformer realtime，仅返回全文，无句级时间戳） | 二期做「自带录音对齐」时扩展 |
| 文生图 | ✅ `/api/wen-image`（万相 wan2.2-t2i-plus） | 作为无 OpenAI key 时的备选生图 |
| 媒体存取 | ✅ `/api/media/([\\w-]+\.(mp4|mp3|png|jpe?g|webp))` | 文件名带 projectId/sceneId 即可复用 |
| 持久化 | ✅ `/api/db`（data/db.json） | 新增 `videoProjects` 键 |

后端约束：**保持 Node 22 零 npm 依赖**（现有 server.js 自带 router，lib 模块一个文件一能力）。

## 二、关键架构决策

1. **旁白 = 逐镜配音，不整段合成。** 每个分镜单独调 `/api/tts`，用 `ffprobe` 实测每段音频时长，
   按此排镜头时间轴。切镜天然对齐旁白，字幕天然对齐，v1 不需要 ASR 对齐。
   （用户自带整段录音 → 二期：扩展 `transcribePcm` 保留 Paraformer 句级 begin/end 时间戳 + 文稿模糊匹配。）
2. **合成用 FFmpeg，v1 不上 Remotion。** 推近/横移用 `zoompan`，多镜用 `concat`，
   字幕烧录用 ASS（可逐字 karaoke、样式可控），旁白音轨直接拼接混入。
   理由：ffmpeg 已装（transcribe 在用）、保持零依赖、避免 Remotion 商用授权 + headless Chrome 的运维成本。
   Remotion 留二期（需要图文入场/前后景视差等更丰富动效时再评估）。
3. **拆分镜走 OpenAI Responses API + Structured Outputs**，固定返回 schema，杜绝「提示词求 JSON + 剥代码围栏」的脆弱解析
   （对比现有 `llm.js` 的 stripFence 方案）。
4. **逐镜生图走 OpenAI Images API（gpt-image-2.6-flare）竖屏尺寸**；同一人物/产品反复出现的镜头
   用 `POST /v1/images/edits` 带同一张参考图控制外观漂移。字幕/标题不进图，留给渲染叠加。
5. **动效 v1 = 一图一动效**：`zoom-in / zoom-out / pan-left / pan-right / static` 五种，全用 ffmpeg filter 实现。
   眨眼/蒸汽类短循环（Images API `output_format: "gif"`，2-16 帧）挑 1-2 镜试点；
   人物走动/完整表演用**通义万相图生视频**（现有 dashscope 账号即可，Sora Videos API 已于 2026-09-24 下线，不考虑）。

## 三、新增模块（workbench-api）

```
src/config.js        + llm.openai: OPENAI_API_KEY（可选 OPENAI_BASE_URL）
src/lib/openai.js    新增：Responses API（structured outputs）+ Images API 适配层
src/lib/storyboard.js 新增：口播稿 → 分镜 JSON（schema 见下）
src/lib/render.js    新增：ffprobe 时长 / zoompan 动效 / concat / ASS 字幕 / 混音导出
src/server.js        新增 6 条 /api/video/* 路由
```

### 分镜 JSON schema（Structured Outputs 固定）

```jsonc
{
  "scenes": [
    {
      "scene_id": "s01",              // 稳定 ID，单镜重跑的关联键
      "text": "……",                   // 原稿对应段落（逐字，供配音和字幕）
      "image_prompt": "……",           // 画面提示词（含风格前缀，保持全片一致）
      "motion": "zoom-in",            // enum: zoom-in|zoom-out|pan-left|pan-right|static
      "motion_note": "缓慢推近"        // 速度/幅度的自然语言描述
    }
  ]
}
```

系统提示词要求：每镜画面讲「这一句在说什么」，如「水蒸气遇冷凝结」→ 冷玻璃上水珠凝结特写 + 缓慢推近；
风格统一竖屏构图；30 秒稿默认 6-8 镜。

### API 路由

| 路由 | 作用 | 幂等性 |
|---|---|---|
| `POST /api/video/project` | 建项目：{ scriptId 或 script, voice } | 新建 |
| `POST /api/video/storyboard` | 全稿拆分镜（重生成 = 整表覆盖，前端先确认） | 按 projectId |
| `PUT  /api/video/scene` | 改单镜 { projectId, scene_id, image_prompt?, motion? } | 单镜 |
| `POST /api/video/scene/image` | 单镜生图 { projectId, scene_id, referenceId? } → 存 media | **单镜重跑** |
| `POST /api/video/narration` | 逐镜 TTS + ffprobe 实测时长 → 时间轴（音频逐镜重跑） | 单镜可重跑 |
| `POST /api/video/render` | 拼装 timeline → ffmpeg 合成 MP4 → 存 media | 整片重渲 |

### 数据模型（db.json `videoProjects`）

```jsonc
{
  "id": "vp-...", "scriptId": "...", "script": "…",
  "voice": "qjj_v2", "aspect": "9:16",
  "status": "draft|storyboard|shot|narrated|rendered",
  "scenes": [{
    "scene_id": "s01", "text": "…", "image_prompt": "…",
    "motion": "zoom-in", "motion_note": "缓慢推近",
    "imageId": "vs-<pid>-s01-img",   // /api/media/vs-<pid>-s01-img.png
    "audioId": "vs-<pid>-s01-aud",   // /api/media/vs-<pid>-s01-aud.mp3
    "durationSec": 4.2, "startSec": 0
  }],
  "outputId": "vs-<pid>-out",        // /api/media/vs-<pid>-out.mp4
  "createdAt": "…", "renderedAt": "…"
}
```

媒体命名 `vs-<projectId>-<sceneId>-<kind>.<ext>` 天然满足 `/api/media` 路由的正则（`[\w-]+`）。

### 渲染管线（render.js，纯 child_process 调 ffmpeg）

1. 每镜：`ffmpeg -loop 1 -i shot.png -i seg.mp3 -t <dur>` + `zoompan`（推近 z 从 1.0→1.12，按 dur 线性）或 `crop+pan`（横移）→ 中间片段 `.ts`
2. 拼接：`concat demuxer` 顺拼所有片段
3. 字幕：由 scenes 的 text/durationSec 生成 `.ass`（每镜一条，可加淡入）→ `-vf ass=` 烧录
4. 导出：`-c:v libx264 -pix_fmt yuv420p -r 30 -s 1080x1920 -c:a aac`（手机端通用兼容参数）

## 四、前端（第 12 个 view：成片工厂）

- 从脚本工厂「发到成片工厂」一键带入（复用现有 `lib/llm.ts` 的 fetch 封装模式）
- 分镜卡片流：原文 / 生成图 / 动效下拉 / 每镜「重生图」「重配音」按钮
- 时间轴条：每镜时长块（实测），点击定位
- 导出按钮 → `<video>` 预览 `vs-<pid>-out.mp4`，产物挂到发布物料

## 五、里程碑（每步可独立验证）

| 里程碑 | 内容 | 验证方式 |
|---|---|---|
| **M1** | `openai.js` + `storyboard.js` + 3 条路由（project/storyboard/scene） | curl 传 30 秒稿 → 返回 6-8 镜 JSON |
| **M2** | 逐镜生图 + 参考图 /edits | 分镜卡片图到位；改 prompt 重跑单镜 |
| **M3** | `narration`（逐镜 TTS + ffprobe） | 每镜 durationSec 与音频实测一致 |
| **M4** | `render.js` + `/api/video/render` | **30 秒竖屏样片：6-8 镜、每镜一图一动效、字幕对齐** ← v1 验收线 |
| **M5** | 前端成片工厂页 | 全流程 UI 走通 |
| **二期** | GIF 镜头试点 / 万相 i2v 个别镜头 / 自带录音 ASR 对齐 / Remotion 评估 | 挑 1-2 个确需主体运动的镜头试 |

## 六、依赖与配置清单

- `.env` 新增：`OPENAI_API_KEY`（必需）、`OPENAI_BASE_URL`（可选，走代理时）
- ffmpeg/ffprobe：已装（transcribe 在用）✅
- npm 依赖：后端 **零新增**；前端复用现有 Vite/React 栈，零新增
- 无需改动 nginx（`/api/*` 转发已覆盖新路由）
